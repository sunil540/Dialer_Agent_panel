// public/env.js
window._env_ = {
    REACT_APP_API_BASE_URL: "http://192.168.1.201:8085/api/"
};
